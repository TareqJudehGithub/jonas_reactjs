function Footer() {
	return <h5>Footer</h5>;
}
export default Footer;
