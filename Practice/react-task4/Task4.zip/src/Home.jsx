function Home() {
	return (
		<div className="">
			<h2 className="row mb-4 p-3">Welcome Home</h2>

			<button className="row btn btn-primary m-1" type="submit">
				Login Out
			</button>
		</div>
	);
}
export default Home;
