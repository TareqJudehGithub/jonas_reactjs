const todos = [
	{ id: 1, task: "Buy milk" },
	{ id: 2, task: "Walk the dog" },
	{ id: 3, task: "Read a book" },
];
const students = [
	{ id: 1, name: "Alice", grade: 85, isPassed: true },
	{ id: 2, name: "Bob", grade: 45, isPassed: false },
	{ id: 3, name: "Charlie", grade: 78, isPassed: true },
];
